@echo off
REM ============================================================
REM  Voice Changer launcher
REM  Just double-click this file to start the voice changer.
REM  A web browser will open automatically once it is ready.
REM
REM  NOTE: Before the first run you must install the requirements
REM        once (see the "Working with the source" section of the
REM        README). After that, just double-click this file.
REM ============================================================

setlocal
REM Move into the "server" folder next to this script.
cd /d "%~dp0server"

REM Activate the Python virtual environment if one was set up.
if exist "venv\Scripts\activate.bat" (
    call "venv\Scripts\activate.bat"
) else (
    echo [!] No "venv" folder found in "server".
    echo     If the voice changer fails to start, install the
    echo     requirements first ^(see the README^).
    echo     Trying system Python for now...
    echo.
)

echo Starting Voice Changer...
echo A browser window will open when the server is ready.
echo Keep THIS window open while you use the voice changer.
echo Close this window ^(or press Ctrl+C^) to stop it.
echo.

REM client.py launches the server and opens the browser automatically.
REM Any extra options you pass to this .bat are forwarded (e.g. --https).
python client.py %*

echo.
echo The voice changer has stopped.
pause
endlocal
