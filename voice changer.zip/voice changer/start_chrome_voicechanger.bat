@echo off
REM ============================================================
REM  Chrome launcher for the Voice Changer web client (run on PC1)
REM
REM  Fixes the "voice stutters unless the Chrome window is focused"
REM  problem. When Chrome's window is covered by OBS / TikTok Studio
REM  (or minimized), Chrome throttles the page's main thread, which
REM  is what ships each audio chunk to/from the voice-changer server.
REM  Throttled main thread -> chunks arrive late -> stutter.
REM
REM  This launches Chrome with that throttling turned OFF, in its own
REM  isolated profile so the flags actually take effect.
REM
REM  It also AUTO-DISCOVERS PC2 by computer name, so you never have to
REM  chase PC2's IP address when it changes after a shutdown.
REM ============================================================

setlocal EnableDelayedExpansion

REM ============================================================
REM  EDIT THIS: PC2's computer name (NOT its IP).
REM
REM  The name is stable -- it does not change when the IP changes.
REM  Find it on PC2 by opening a command prompt and typing:
REM       hostname
REM  (or Settings > System > About > "Device name").
REM ============================================================
set PC2_NAME=DESKTOP-PC2

REM  Port + scheme. PC2-host mode uses https (needed for the mic
REM  from another PC). If you run the voice changer on THIS PC, set
REM  SCHEME=http and PC2_NAME=localhost.
set PORT=18888
set SCHEME=https

REM  Optional manual override. If you fill this in, auto-discovery is
REM  skipped and this exact address is used, e.g.
REM       set SERVER_URL=https://192.168.1.50:18888
set SERVER_URL=

REM --- Auto-discover PC2 by name (resolve -> IP, verify port) -
if not defined SERVER_URL (
    echo Looking for "%PC2_NAME%" on the network...
    for /f "usebackq delims=" %%I in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$names=@('%PC2_NAME%','%PC2_NAME%.local'); $port=%PORT%; foreach($n in $names){ try { $ips=[System.Net.Dns]::GetHostAddresses($n) ^| Where-Object { $_.AddressFamily -eq 'InterNetwork' } } catch { continue }; foreach($ip in $ips){ $c=New-Object Net.Sockets.TcpClient; try { $r=$c.BeginConnect($ip,$port,$null,$null); if($r.AsyncWaitHandle.WaitOne(700) -and $c.Connected){ Write-Output $ip.IPAddressToString; $c.Close(); exit } } catch {} finally { $c.Close() } } }"`) do set FOUND_IP=%%I
    if defined FOUND_IP (
        set SERVER_URL=%SCHEME%://!FOUND_IP!:%PORT%
        echo Found PC2 at !FOUND_IP!
    ) else (
        goto :not_found
    )
)

REM --- The anti-throttling flags (the actual stutter fix) -----
set FLAGS=--disable-backgrounding-occluded-windows --disable-renderer-backgrounding --disable-background-timer-throttling

REM --- Isolated profile so the flags above actually apply -----
REM     (Chrome ignores flags when joining an already-running process.)
set PROFILE_DIR=%~dp0chrome-voicechanger-profile

REM --- Trust PC2's self-signed cert (https), so the mic works --
echo %SERVER_URL% | findstr /I /C:"https" >nul
if not errorlevel 1 set FLAGS=%FLAGS% --ignore-certificate-errors

REM --- Locate chrome.exe --------------------------------------
set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined CHROME goto :no_chrome

echo Launching Chrome for the voice changer...
echo   URL    : %SERVER_URL%
echo   Profile: %PROFILE_DIR%
echo.

start "" "%CHROME%" %FLAGS% --user-data-dir="%PROFILE_DIR%" --new-window "%SERVER_URL%"
goto :eof

:not_found
echo.
echo  Could not find "%PC2_NAME%" on port %PORT%.
echo  Checklist:
echo    * Is PC2 turned on and the voice changer running on it?
echo    * Is PC2_NAME set correctly in this .bat (run "hostname" on PC2)?
echo    * Are both PCs on the same network?
echo.
echo  Tip: if name discovery never works on your network, set a
echo  fixed address in SERVER_URL near the top of this file, and/or
echo  reserve a static IP for PC2 in your router settings.
echo.
pause
goto :eof

:no_chrome
echo.
echo  ERROR: Could not find chrome.exe in the usual locations.
echo  If Chrome is installed elsewhere, open this .bat in a text
echo  editor and set CHROME to the full path of chrome.exe.
echo.
pause
goto :eof
