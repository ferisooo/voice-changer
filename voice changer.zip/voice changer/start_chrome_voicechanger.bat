@echo off
REM ============================================================
REM  Chrome launcher for the Voice Changer web client (run on PC1)
REM
REM  Fixes the "voice stutters unless the Chrome window is focused"
REM  problem. When Chrome's window is covered by OBS / TikTok Studio
REM  (or minimized), Chrome throttles the page's main thread, which
REM  is what ships each audio chunk to/from the voice-changer server.
REM  Throttled main thread -> chunks arrive late -> stutter.
REM
REM  This launches Chrome with that throttling turned OFF, in its own
REM  isolated profile so the flags actually take effect.
REM
REM  IMPORTANT: the flags only apply when Chrome starts a NEW process.
REM  That is why this uses a dedicated --user-data-dir. If you instead
REM  add flags to your normal Chrome (which is already running), they
REM  are ignored.
REM ============================================================

setlocal

REM ============================================================
REM  EDIT THIS: the address of the machine running the voice
REM  changer.
REM
REM   * PC2-host mode (this PC1 connecting to PC2 over the LAN):
REM       use https and PC2's LAN IP, e.g.
REM       set SERVER_URL=https://192.168.1.50:18888
REM
REM   * Running the voice changer on THIS same PC:
REM       set SERVER_URL=http://localhost:18888
REM ============================================================
set SERVER_URL=https://192.168.1.50:18888

REM --- The anti-throttling flags (the actual fix) -------------
REM  disable-backgrounding-occluded-windows : don't slow down when
REM       the window is covered by OBS / a game / TikTok Studio.
REM  disable-renderer-backgrounding         : keep the tab's thread
REM       at full priority even when not focused.
REM  disable-background-timer-throttling    : don't slow timers in
REM       the background.
set FLAGS=--disable-backgrounding-occluded-windows --disable-renderer-backgrounding --disable-background-timer-throttling

REM --- Isolated profile so the flags above actually apply -----
set PROFILE_DIR=%~dp0chrome-voicechanger-profile

REM --- PC2-host mode serves HTTPS with a self-signed cert.
REM     Trust it for this isolated profile so you are not nagged.
REM     (The page is still a secure context, so the mic works.)
echo %SERVER_URL% | findstr /I /C:"https" >nul
if not errorlevel 1 set FLAGS=%FLAGS% --ignore-certificate-errors

REM --- Locate chrome.exe --------------------------------------
set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined CHROME if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined CHROME goto :no_chrome

echo Launching Chrome for the voice changer...
echo   URL    : %SERVER_URL%
echo   Profile: %PROFILE_DIR%
echo.

start "" "%CHROME%" %FLAGS% --user-data-dir="%PROFILE_DIR%" --new-window "%SERVER_URL%"
goto :eof

:no_chrome
echo.
echo  ERROR: Could not find chrome.exe in the usual locations.
echo  If Chrome is installed elsewhere, open this .bat in a text
echo  editor and set CHROME to the full path of chrome.exe.
echo.
pause
goto :eof
