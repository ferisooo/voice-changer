"""
Optional AI speech enhancement (DeepFilterNet) applied to the converted output.

Design goals:
  * Fully isolated: if the dependency is missing or anything fails at runtime,
    the audio is passed through UNCHANGED and normal conversion is never broken.
  * Lazy: DeepFilterNet is only imported/loaded the first time it is enabled,
    so the server starts fine even when the package is not installed.
"""
import logging
import numpy as np

logger = logging.getLogger(__name__)


class PostEnhancer:
    def __init__(self):
        self._model = None
        self._df_state = None
        self._sr = 48000
        self._loaded = False
        self._failed = False
        self._error = ""

    def is_available(self) -> bool:
        """Whether the DeepFilterNet package is importable."""
        try:
            import df  # noqa: F401
            return True
        except Exception:
            return False

    def status(self) -> dict:
        return {
            "available": self.is_available(),
            "loaded": self._loaded,
            "failed": self._failed,
            "error": self._error,
        }

    def _ensure_loaded(self) -> bool:
        if self._loaded:
            return True
        if self._failed:
            return False
        try:
            from df.enhance import init_df
            self._model, self._df_state, _ = init_df()
            try:
                self._sr = int(self._df_state.sr())
            except Exception:
                self._sr = 48000
            self._loaded = True
            logger.info("PostEnhancer (DeepFilterNet) loaded. SR=%d", self._sr)
        except Exception as e:
            self._failed = True
            self._error = str(e)
            logger.error("PostEnhancer failed to load: %s", e)
        return self._loaded

    @staticmethod
    def _resample(x: np.ndarray, sr_from: int, sr_to: int) -> np.ndarray:
        if sr_from == sr_to or len(x) == 0:
            return x
        n_out = int(round(len(x) * sr_to / sr_from))
        if n_out <= 1:
            return x
        idx = np.linspace(0, len(x) - 1, n_out)
        return np.interp(idx, np.arange(len(x)), x).astype(np.float32)

    def enhance(self, audio: np.ndarray, sample_rate: int) -> np.ndarray:
        """Return enhanced audio, or the original audio on any problem."""
        if not self._ensure_loaded():
            return audio
        try:
            import torch
            from df.enhance import enhance as df_enhance

            n = len(audio)
            x = self._resample(audio, sample_rate, self._sr)
            t = torch.from_numpy(np.ascontiguousarray(x, dtype=np.float32)).unsqueeze(0)
            out = df_enhance(self._model, self._df_state, t)
            out = out.squeeze(0).detach().cpu().numpy().astype(np.float32)
            out = self._resample(out, self._sr, sample_rate)
            # Keep exactly the original block length.
            if len(out) > n:
                out = out[:n]
            elif len(out) < n:
                out = np.pad(out, (0, n - len(out)))
            return out
        except Exception as e:
            # Disable on first runtime failure so we don't spam errors per chunk.
            self._failed = True
            self._error = str(e)
            logger.error("PostEnhancer runtime error, disabling: %s", e)
            return audio
